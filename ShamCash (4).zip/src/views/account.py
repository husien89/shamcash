import flet as ft

from theme import BLUE, CARD, LINE, MUTED, TEXT, WHITE


def build_account(on_back, on_logout):
    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
                content=ft.Column(
                    spacing=18,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.IconButton(icon=ft.Icons.ARROW_FORWARD, icon_color=TEXT, on_click=on_back),
                                ft.Text("حسابي", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.Container(width=42),
                            ],
                        ),
                        ft.Container(
                            padding=ft.Padding.all(20),
                            border=ft.Border.all(1, LINE),
                            border_radius=22,
                            bgcolor=CARD,
                            content=ft.Row(
                                spacing=14,
                                controls=[
                                    ft.Container(
                                        width=56,
                                        height=56,
                                        border_radius=28,
                                        bgcolor=BLUE,
                                        alignment=ft.Alignment.CENTER,
                                        content=ft.Text("A", size=23, weight=ft.FontWeight.BOLD, color=WHITE),
                                    ),
                                    ft.Column(
                                        spacing=4,
                                        controls=[
                                            ft.Text("admin", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                                            ft.Text("حساب مدير تجريبي", size=12, color=MUTED),
                                        ],
                                    ),
                                ],
                            ),
                        ),
                        ft.Text("الأمان والخصوصية", size=14, color=MUTED),
                        ft.Container(
                            padding=ft.Padding.all(15),
                            border=ft.Border.all(1, LINE),
                            border_radius=16,
                            bgcolor=CARD,
                            content=ft.Row(
                                spacing=10,
                                controls=[
                                    ft.Icon(ft.Icons.FINGERPRINT, color=BLUE),
                                    ft.Text("الدخول بالبصمة متاح للعرض فقط", size=13, color=TEXT),
                                ],
                            ),
                        ),
                        ft.Button(content="تسجيل الخروج", icon=ft.Icons.LOGOUT, bgcolor="#49303B", color=WHITE, on_click=on_logout),
                        ft.Text("ShamCash · نسخة تجريبية", size=11, color=MUTED, text_align=ft.TextAlign.CENTER),
                    ],
                ),
            ),
        ],
    )
