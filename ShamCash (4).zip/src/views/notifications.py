import flet as ft

from components.transaction import build_transaction_card
from theme import BLUE, CARD, GREEN, LINE, MUTED, TEXT


def build_notifications(transactions, on_open, on_back):
    latest = transactions[:6]
    cards = []
    for item in latest:
        outgoing = item.get("direction", "out") == "out"
        message = "تم تسجيل عملية الإرسال التجريبية" if outgoing else "تم تسجيل عملية الاستلام التجريبية"
        cards.append(
            ft.Container(
                padding=ft.Padding.all(14),
                border=ft.Border.all(1, LINE),
                border_radius=17,
                bgcolor=CARD,
                content=ft.Column(
                    spacing=10,
                    controls=[
                        ft.Row(
                            spacing=8,
                            controls=[
                                ft.Icon(ft.Icons.NOTIFICATIONS_ACTIVE, color=GREEN if not outgoing else BLUE, size=19),
                                ft.Text(message, size=13, color=TEXT, expand=True),
                            ],
                        ),
                        build_transaction_card(item, on_click=on_open, compact=True),
                    ],
                ),
            )
        )

    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
                content=ft.Column(
                    spacing=15,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.IconButton(icon=ft.Icons.ARROW_FORWARD, icon_color=TEXT, on_click=on_back),
                                ft.Text("الإشعارات", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.Container(width=42),
                            ],
                        ),
                        ft.Text("تنبيهات التحويلات", size=14, color=MUTED),
                        *cards,
                        *([ft.Text("لا توجد إشعارات حالياً", color=MUTED)] if not cards else []),
                    ],
                ),
            ),
        ],
    )
