import flet as ft

from theme import BLUE, CARD, CARD_ALT, GREEN, LINE, MUTED, RED, SURFACE, TEXT, WHITE


FAVORITES = ["جودت خليفه الوالي", "محمدانس الكطوز", "عبد الرحمن العثمان"]


def build_send(balance, on_send, on_pick_image, on_back):
    recipient = ft.TextField(
        label="عنوان المحفظة أو رقم الحساب",
        hint_text="أدخل العنوان أو الصقه هنا",
        filled=True,
        fill_color=SURFACE,
        color=TEXT,
        label_style=ft.TextStyle(color=MUTED),
        hint_style=ft.TextStyle(color=MUTED),
        border={
            ft.ControlState.DEFAULT: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=LINE, width=1)),
            ft.ControlState.FOCUSED: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=BLUE, width=2)),
        },
        text_align=ft.TextAlign.RIGHT,
    )
    amount = ft.TextField(
        label="المبلغ",
        hint_text="0",
        keyboard_type=ft.KeyboardType.NUMBER,
        filled=True,
        fill_color=SURFACE,
        color=TEXT,
        label_style=ft.TextStyle(color=MUTED),
        hint_style=ft.TextStyle(color=MUTED),
        border={
            ft.ControlState.DEFAULT: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=LINE, width=1)),
            ft.ControlState.FOCUSED: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=BLUE, width=2)),
        },
        text_align=ft.TextAlign.RIGHT,
    )
    note = ft.TextField(
        label="ملاحظة (اختياري)",
        hint_text="سبب التحويل",
        filled=True,
        fill_color=SURFACE,
        color=TEXT,
        label_style=ft.TextStyle(color=MUTED),
        hint_style=ft.TextStyle(color=MUTED),
        border={
            ft.ControlState.DEFAULT: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=LINE, width=1)),
            ft.ControlState.FOCUSED: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=BLUE, width=2)),
        },
        text_align=ft.TextAlign.RIGHT,
    )
    feedback = ft.Container(height=20, content=ft.Text("", size=12, color=RED))
    picked_file = ft.Text("اضغط لاختيار صورة الإيصال أو QR", size=14, color=TEXT)

    async def focus_recipient():
        await recipient.focus()

    async def submit():
        result = await on_send(recipient.value or "", amount.value or "", note.value or "")
        if isinstance(result, str) and result:
            feedback.content.value = result
            feedback.update()

    async def pick_image():
        name = await on_pick_image()
        if name:
            picked_file.value = f"تم اختيار: {name}"
            picked_file.update()

    def choose_favorite(name):
        recipient.value = name
        recipient.update()

    favorites = ft.Row(
        scroll=ft.ScrollMode.AUTO,
        spacing=8,
        controls=[
            ft.TextButton(
                content=name,
                on_click=lambda e, selected=name: choose_favorite(selected),
                style=ft.ButtonStyle(color=TEXT, bgcolor=CARD_ALT),
            )
            for name in FAVORITES
        ],
    )

    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
                content=ft.Column(
                    spacing=17,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.IconButton(icon=ft.Icons.ARROW_FORWARD, icon_color=TEXT, bgcolor=CARD, on_click=on_back),
                                ft.Text("إرسال", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.Container(width=42),
                            ],
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.Text("المفضلة  ♡", size=16, color=MUTED),
                                ft.Button(content="جديد  +", bgcolor=CARD_ALT, color=TEXT, on_click=focus_recipient),
                            ],
                        ),
                        favorites,
                        ft.Container(
                            height=205,
                            border=ft.Border.all(2, BLUE),
                            border_radius=24,
                            alignment=ft.Alignment.CENTER,
                            ink=True,
                            on_click=pick_image,
                            content=ft.Column(
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                alignment=ft.MainAxisAlignment.CENTER,
                                spacing=12,
                                controls=[
                                    ft.Icon(ft.Icons.CLOUD_UPLOAD, size=66, color=TEXT),
                                    picked_file,
                                ],
                            ),
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=12,
                            controls=[ft.Container(width=54, height=1, bgcolor=LINE), ft.Text("أو", color=MUTED), ft.Container(width=54, height=1, bgcolor=LINE)],
                        ),
                        recipient,
                        amount,
                        note,
                        feedback,
                        ft.Button(
                            content="إظهار الحساب والمتابعة",
                            icon=ft.Icons.ACCOUNT_BALANCE_WALLET,
                            bgcolor=BLUE,
                            color=WHITE,
                            on_click=submit,
                        ),
                        ft.Text(f"رصيد تجريبي متاح: {balance:,.0f} ل.س", size=12, color=MUTED),
                    ],
                ),
            ),
        ],
    )
