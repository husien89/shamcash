import flet as ft

from theme import BLUE, CARD, LINE, MUTED, TEXT


SERVICES = [
    (ft.Icons.ACCOUNT_BALANCE, "بنوك"),
    (ft.Icons.RECEIPT_LONG, "فواتير"),
    (ft.Icons.PAYMENTS, "مدفوعات"),
    (ft.Icons.SWAP_HORIZ, "حوالات"),
    (ft.Icons.STAR, "خدماتي"),
]


def build_services(on_back, on_send):
    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
                content=ft.Column(
                    spacing=16,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.IconButton(icon=ft.Icons.ARROW_FORWARD, icon_color=TEXT, on_click=on_back),
                                ft.Text("الخدمات", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.Container(width=42),
                            ],
                        ),
                        *[
                            ft.Container(
                                padding=ft.Padding.all(15),
                                border=ft.Border.all(1, LINE),
                                border_radius=17,
                                bgcolor=CARD,
                                ink=True,
                                on_click=on_send,
                                content=ft.Row(
                                    spacing=12,
                                    controls=[
                                        ft.Icon(icon, color=BLUE, size=23),
                                        ft.Text(label, size=15, color=TEXT, expand=True),
                                        ft.Icon(ft.Icons.CHEVRON_LEFT, color=MUTED),
                                    ],
                                ),
                            )
                            for icon, label in SERVICES
                        ],
                        ft.Text("الخدمات هنا للعرض، وتحتاج ربطاً بالخادم لتفعيلها.", size=12, color=MUTED),
                    ],
                ),
            ),
        ],
    )
