import flet as ft

from theme import BLUE, CARD, GREEN, LINE, MUTED, RED, TEXT, WHITE


def _detail(label, value):
    return ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        spacing=12,
        controls=[
            ft.Text(value or "—", size=14, color=WHITE, text_align=ft.TextAlign.LEFT, expand=True),
            ft.Text(label, size=14, color=MUTED, text_align=ft.TextAlign.RIGHT),
        ],
    )


def build_receipt(item, on_back):
    outgoing = item.get("direction", "out") == "out"
    direction = "إرسال" if outgoing else "استلام"
    amount = float(item.get("amount", 0))
    currency = item.get("currency", "ل.س")
    result = ft.Text("", size=12, color=GREEN, text_align=ft.TextAlign.CENTER)

    def export_preview():
        result.value = "تم تجهيز معاينة الإيصال التجريبية. لا يتم إنشاء مستند مالي رسمي."
        result.update()

    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
                content=ft.Column(
                    spacing=16,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.IconButton(icon=ft.Icons.ARROW_FORWARD, icon_color=TEXT, bgcolor=CARD, on_click=on_back),
                                ft.Text("العملية", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.Container(width=42),
                            ],
                        ),
                        ft.Container(
                            padding=ft.Padding.all(19),
                            border=ft.Border.all(1, LINE),
                            border_radius=24,
                            bgcolor=CARD,
                            content=ft.Column(
                                spacing=15,
                                controls=[
                                    ft.Row(
                                        alignment=ft.MainAxisAlignment.END,
                                        spacing=10,
                                        controls=[
                                            ft.Text("ShamCash", size=21, weight=ft.FontWeight.BOLD, color=TEXT),
                                            ft.Image(src="icon.svg", width=42, height=42, fit=ft.BoxFit.CONTAIN),
                                        ],
                                    ),
                                    ft.Divider(color=LINE, thickness=1),
                                    _detail("العملية", direction),
                                    _detail("رقم العملية", f"#{item.get('id', '603510700')}"),
                                    _detail("تاريخ العملية", item.get("subtitle", "اليوم")),
                                    _detail("اسم المرسل", item.get("sender", "حسين أحمد الفارس")),
                                    _detail("حساب المرسل", item.get("sender_account", "************2846")),
                                    _detail("اسم المستلم", item.get("recipient", item.get("title", "مستخدم ShamCash"))),
                                    _detail("حساب المستلم", item.get("recipient_account", "************3734")),
                                    _detail("المبلغ", f"{amount:,.0f} {currency}"),
                                    _detail("الملاحظة", item.get("note", "—")),
                                    ft.Divider(color=LINE, thickness=1),
                                    ft.Row(
                                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                                        controls=[
                                            ft.Text("تم الإنشاء عبر ShamCash", size=12, color=MUTED),
                                            ft.Container(
                                                padding=ft.Padding.symmetric(horizontal=10, vertical=5),
                                                border_radius=14,
                                                bgcolor="#253D3A" if not outgoing else "#49303B",
                                                content=ft.Text("مكتملة · تجريبية", size=11, color=GREEN if not outgoing else RED),
                                            ),
                                        ],
                                    ),
                                ],
                            ),
                        ),
                        ft.Button(content="استخراج الإيصال", bgcolor=BLUE, color=WHITE, on_click=export_preview),
                        ft.OutlinedButton(content="مشاركة الإيصال", on_click=export_preview, style=ft.ButtonStyle(color=TEXT, side=ft.BorderSide(width=1, color=LINE))),
                        result,
                    ],
                ),
            ),
        ],
    )
