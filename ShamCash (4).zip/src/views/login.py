import flet as ft

from theme import BLUE, CARD, LINE, MUTED, SURFACE, TEXT, WHITE


def build_login(on_login):
    username = ft.TextField(
        label="اسم المستخدم",
        value="admin",
        filled=True,
        fill_color=SURFACE,
        color=TEXT,
        label_style=ft.TextStyle(color=MUTED),
        border={
            ft.ControlState.DEFAULT: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=LINE, width=1)),
            ft.ControlState.FOCUSED: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=BLUE, width=2)),
        },
        text_align=ft.TextAlign.RIGHT,
    )
    password = ft.TextField(
        label="كلمة المرور",
        value="",
        password=True,
        can_reveal_password=True,
        filled=True,
        fill_color=SURFACE,
        color=TEXT,
        label_style=ft.TextStyle(color=MUTED),
        border={
            ft.ControlState.DEFAULT: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=LINE, width=1)),
            ft.ControlState.FOCUSED: ft.OutlineInputBorder(border_radius=14, side=ft.BorderSide(color=BLUE, width=2)),
        },
        text_align=ft.TextAlign.RIGHT,
    )
    message = ft.Text("", size=12, color="#E97982", text_align=ft.TextAlign.CENTER)

    async def submit():
        success = await on_login(username.value or "", password.value or "")
        if not success:
            message.value = "بيانات الدخول غير صحيحة. جرّب admin / admin123"
            message.update()

    password.on_submit = submit

    async def demo_biometric():
        password.value = "admin123"
        password.update()
        await submit()

    return ft.Column(
        expand=True,
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=24, vertical=25),
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=20,
                    controls=[
                        ft.Icon(ft.Icons.LOCK, color=BLUE, size=82),
                        ft.Text("تسجيل الدخول", size=24, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=8,
                            controls=[
                                ft.Image(src="icon.svg", width=44, height=44, fit=ft.BoxFit.CONTAIN),
                                ft.Text("ShamCash", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                            ],
                        ),
                        ft.Container(
                            padding=ft.Padding.all(18),
                            border_radius=24,
                            border=ft.Border.all(1, LINE),
                            bgcolor=CARD,
                            content=ft.Column(
                                spacing=14,
                                controls=[
                                    username,
                                    password,
                                    message,
                                    ft.Button(content="دخول", bgcolor=BLUE, color=WHITE, on_click=submit),
                                    ft.TextButton(content="دخول بالبصمة (عرض فقط)", icon=ft.Icons.FINGERPRINT, on_click=demo_biometric, style=ft.ButtonStyle(color=TEXT)),
                                    ft.Text("حساب العرض: admin  ·  كلمة المرور: admin123", size=11, color=MUTED, text_align=ft.TextAlign.CENTER),
                                ],
                            ),
                        ),
                        ft.Text("نسخة واجهة تجريبية — لا تستخدم بيانات حساب حقيقية", size=11, color=MUTED, text_align=ft.TextAlign.CENTER),
                    ],
                ),
            ),
        ],
    )
