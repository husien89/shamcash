import flet as ft

from components.transaction import build_transaction_card
from theme import BLUE_LIGHT, MUTED, TEXT


def build_activity(transactions, on_open, on_back):
    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
                content=ft.Column(
                    spacing=15,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.IconButton(icon=ft.Icons.ARROW_FORWARD, icon_color=TEXT, on_click=on_back),
                                ft.Text("التحويلات", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.TextButton(content="متقدم", style=ft.ButtonStyle(color=BLUE_LIGHT)),
                            ],
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.Text("اضغط على عملية لعرض الإيصال", size=13, color=MUTED),
                                ft.Icon(ft.Icons.INFO_OUTLINE, color=MUTED, size=18),
                            ],
                        ),
                        *[
                            build_transaction_card(item, on_click=on_open)
                            for item in transactions
                        ],
                        *([ft.Text("لا توجد تحويلات حالياً", color=MUTED)] if not transactions else []),
                    ],
                ),
            ),
        ],
    )
