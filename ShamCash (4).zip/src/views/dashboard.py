import flet as ft

from components.transaction import build_transaction_card
from theme import BG, BLUE, BLUE_LIGHT, CARD, GREEN, LINE, MUTED, RED, SURFACE, TEAL, TEXT, WHITE


DEMO_USD_RATE = 15000


def _service(icon, label, on_click):
    return ft.Container(
        expand=True,
        ink=True,
        on_click=on_click,
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=9,
            controls=[
                ft.Container(
                    width=58,
                    height=58,
                    alignment=ft.Alignment.CENTER,
                    border_radius=29,
                    bgcolor=CARD,
                    border=ft.Border.all(1, LINE),
                    content=ft.Icon(icon, color=TEXT, size=23),
                ),
                ft.Text(label, size=11, color=TEXT, text_align=ft.TextAlign.CENTER, max_lines=1),
            ],
        ),
    )


def build_dashboard(balance, transactions, go_send, go_receive, go_activity, go_services, go_account, go_notifications, open_transaction):
    balance_text = ft.Text("", size=33, weight=ft.FontWeight.BOLD, color=TEXT)
    currency_note = ft.Text("سعر توضيحي للعرض فقط", size=10, color=MUTED)
    hidden = {"value": False}
    currency = {"value": "SYP"}
    visibility = ft.IconButton(icon=ft.Icons.VISIBILITY_OFF, icon_color=MUTED, icon_size=20, on_click=lambda e: toggle_balance())
    syp_chip = ft.Container(border_radius=20, padding=ft.Padding.symmetric(horizontal=15, vertical=8), bgcolor=BLUE, content=ft.Text("ليرة", color=WHITE, size=12, weight=ft.FontWeight.BOLD))
    usd_chip = ft.Container(border_radius=20, padding=ft.Padding.symmetric(horizontal=15, vertical=8), content=ft.Text("دولار", color=MUTED, size=12))

    def update_balance():
        if hidden["value"]:
            balance_text.value = "••••••••"
        elif currency["value"] == "SYP":
            balance_text.value = f"{balance:,.0f} ل.س"
        else:
            balance_text.value = f"{balance / DEMO_USD_RATE:,.2f} USD"
        syp_chip.bgcolor = BLUE if currency["value"] == "SYP" else None
        usd_chip.bgcolor = BLUE if currency["value"] == "USD" else None
        syp_chip.content.color = WHITE if currency["value"] == "SYP" else MUTED
        usd_chip.content.color = WHITE if currency["value"] == "USD" else MUTED

    def toggle_balance():
        hidden["value"] = not hidden["value"]
        visibility.icon = ft.Icons.VISIBILITY if hidden["value"] else ft.Icons.VISIBILITY_OFF
        update_balance()
        balance_text.update()
        visibility.update()
        syp_chip.update()
        usd_chip.update()

    def select_currency(value):
        currency["value"] = value
        update_balance()
        balance_text.update()
        syp_chip.update()
        usd_chip.update()
        currency_note.value = "تحويل توضيحي 1 USD = 15,000 ل.س · ليس سعراً حقيقياً" if value == "USD" else "الرصيد التوضيحي للمحفظة"
        currency_note.update()

    syp_chip.on_click = lambda e: select_currency("SYP")
    usd_chip.on_click = lambda e: select_currency("USD")
    update_balance()

    transactions_section = [
        ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            controls=[
                ft.Text("آخر التحويلات", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                ft.TextButton(content="عرض الكل", on_click=go_activity, style=ft.ButtonStyle(color=BLUE_LIGHT)),
            ],
        )
    ]
    transactions_section.extend(
        build_transaction_card(item, on_click=open_transaction, compact=True)
        for item in transactions[:4]
    )
    if not transactions:
        transactions_section.append(ft.Text("لا توجد تحويلات حتى الآن", color=MUTED))

    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        spacing=18,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=18, vertical=15),
                content=ft.Column(
                    spacing=19,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.IconButton(icon=ft.Icons.NOTIFICATIONS_NONE, icon_color=TEXT, bgcolor=CARD, on_click=go_notifications),
                                ft.Row(
                                    spacing=8,
                                    controls=[
                                        ft.Image(src="icon.svg", width=42, height=42, fit=ft.BoxFit.CONTAIN),
                                        ft.Text("ShamCash", size=21, weight=ft.FontWeight.BOLD, color=TEXT),
                                    ],
                                ),
                            ],
                        ),
                        ft.Container(
                            padding=ft.Padding.all(19),
                            border_radius=28,
                            bgcolor=CARD,
                            border=ft.Border.all(1, LINE),
                            content=ft.Column(
                                spacing=17,
                                controls=[
                                    ft.Row(
                                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                                        controls=[
                                            ft.Row(
                                                spacing=8,
                                                controls=[
                                                    ft.Container(
                                                        width=42,
                                                        height=42,
                                                        border_radius=21,
                                                        bgcolor=BLUE,
                                                        alignment=ft.Alignment.CENTER,
                                                        content=ft.Icon(ft.Icons.ACCOUNT_BALANCE_WALLET, color=WHITE, size=22),
                                                    ),
                                                    ft.Text("إجمالي الرصيد", size=15, color=TEXT),
                                                ],
                                            ),
                                            visibility,
                                        ],
                                    ),
                                    ft.Row(
                                        controls=[
                                            ft.Container(
                                                padding=ft.Padding.symmetric(horizontal=12, vertical=5),
                                                border_radius=15,
                                                bgcolor=SURFACE,
                                                content=ft.Row(spacing=5, controls=[syp_chip, usd_chip]),
                                            ),
                                        ],
                                    ),
                                    balance_text,
                                    currency_note,
                                    ft.Row(
                                        spacing=12,
                                        controls=[
                                            ft.Container(
                                                expand=True,
                                                padding=ft.Padding.symmetric(horizontal=14, vertical=13),
                                                border_radius=20,
                                                bgcolor=SURFACE,
                                                border=ft.Border.all(1, LINE),
                                                ink=True,
                                                on_click=go_send,
                                                content=ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=8, controls=[ft.Icon(ft.Icons.SEND, color=RED), ft.Text("إرسال", color=RED, weight=ft.FontWeight.BOLD)]),
                                            ),
                                            ft.Container(
                                                expand=True,
                                                padding=ft.Padding.symmetric(horizontal=14, vertical=13),
                                                border_radius=20,
                                                bgcolor=SURFACE,
                                                border=ft.Border.all(1, LINE),
                                                ink=True,
                                                on_click=go_receive,
                                                content=ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=8, controls=[ft.Icon(ft.Icons.SOUTH_EAST, color=GREEN), ft.Text("استلام", color=GREEN, weight=ft.FontWeight.BOLD)]),
                                            ),
                                        ],
                                    ),
                                ],
                            ),
                        ),
                        ft.Row(
                            spacing=9,
                            controls=[
                                _service(ft.Icons.ACCOUNT_BALANCE, "بنوك", go_services),
                                _service(ft.Icons.RECEIPT_LONG, "فواتير", go_services),
                                _service(ft.Icons.PAYMENTS, "مدفوعات", go_services),
                                _service(ft.Icons.SWAP_HORIZ, "حوالات", go_send),
                                _service(ft.Icons.STAR, "خدماتي", go_services),
                            ],
                        ),
                        ft.Column(spacing=11, controls=transactions_section),
                        ft.Container(height=16, bgcolor=BG),
                    ],
                ),
            ),
        ],
    )
