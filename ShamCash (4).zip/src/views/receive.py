import flet as ft

from theme import BLUE, CARD, LINE, MUTED, SURFACE, TEXT, WHITE


WALLET_CODE = "6a2c4be8fdd16ec0c898182b29d71e72"


def build_receive(on_copy, on_back):
    copied = ft.Text("", size=12, color=BLUE)

    async def copy_code():
        await on_copy(WALLET_CODE)
        copied.value = "تم نسخ عنوان المحفظة التجريبي"
        copied.update()

    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=20,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.IconButton(icon=ft.Icons.ARROW_FORWARD, icon_color=TEXT, bgcolor=CARD, on_click=on_back),
                                ft.Text("استلام", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.Container(width=42),
                            ],
                        ),
                        ft.Text("شارك رمز المحفظة لاستلام الأموال", size=14, color=MUTED),
                        ft.Container(
                            width=280,
                            height=360,
                            alignment=ft.Alignment.CENTER,
                            border_radius=18,
                            border=ft.Border.all(1, LINE),
                            bgcolor=WHITE,
                            content=ft.Column(
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                alignment=ft.MainAxisAlignment.CENTER,
                                spacing=10,
                                controls=[
                                    ft.Image(src="icon.svg", width=52, height=52, fit=ft.BoxFit.CONTAIN),
                                    ft.Icon(ft.Icons.QR_CODE_2, size=220, color="#34446E"),
                                    ft.Text("رمز QR تجريبي", color="#34446E", size=12),
                                ],
                            ),
                        ),
                        ft.Container(
                            width=280,
                            padding=ft.Padding.all(15),
                            border_radius=16,
                            bgcolor=SURFACE,
                            content=ft.Column(
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                spacing=6,
                                controls=[
                                    ft.Text("عنوان محفظة العرض", size=12, color=MUTED),
                                    ft.Text(WALLET_CODE, size=13, color=TEXT, selectable=True, text_align=ft.TextAlign.CENTER),
                                ],
                            ),
                        ),
                        ft.Button(content="نسخ عنوان المحفظة", icon=ft.Icons.CONTENT_COPY, bgcolor=BLUE, color=WHITE, on_click=copy_code),
                        copied,
                        ft.Text("الرمز والعنوان للعرض فقط ولا يستقبلان أموالاً حقيقية.", size=11, color=MUTED, text_align=ft.TextAlign.CENTER),
                    ],
                ),
            ),
        ],
    )
