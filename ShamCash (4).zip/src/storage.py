import json

from data import SEED_BALANCE, SEED_TRANSACTIONS


BALANCE_KEY = "shamcash.demo.balance"
TRANSACTIONS_KEY = "shamcash.demo.transactions"


async def load_wallet(preferences):
    saved_balance = await preferences.get(BALANCE_KEY)
    saved_transactions = await preferences.get(TRANSACTIONS_KEY)

    try:
        balance = float(saved_balance) if saved_balance is not None else SEED_BALANCE
    except (TypeError, ValueError):
        balance = SEED_BALANCE

    try:
        transactions = json.loads(saved_transactions) if saved_transactions else None
        if not isinstance(transactions, list):
            transactions = None
    except (TypeError, ValueError):
        transactions = None

    if transactions is None:
        transactions = [item.copy() for item in SEED_TRANSACTIONS]

    return balance, transactions


async def save_wallet(preferences, balance, transactions):
    await preferences.set(BALANCE_KEY, float(balance))
    await preferences.set(TRANSACTIONS_KEY, json.dumps(transactions, ensure_ascii=False))
