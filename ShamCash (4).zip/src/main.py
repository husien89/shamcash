import logging

import flet as ft

from storage import load_wallet, save_wallet
from theme import BG, BLUE, CARD, MUTED, TEXT, WHITE
from views.account import build_account
from views.activity import build_activity
from views.dashboard import build_dashboard
from views.login import build_login
from views.notifications import build_notifications
from views.receive import build_receive
from views.receipt import build_receipt
from views.send import build_send
from views.services import build_services


LOG_LEVEL = logging.INFO
logging.basicConfig(format="%(levelname)s %(name)s: %(message)s")
logging.getLogger("app").setLevel(LOG_LEVEL)
log = logging.getLogger("app.main")


async def main(page: ft.Page):
    page.title = "ShamCash"
    page.theme = ft.Theme(color_scheme_seed=ft.Colors.INDIGO)
    page.dark_theme = ft.Theme(color_scheme_seed=ft.Colors.INDIGO)
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = BG
    page.padding = 0
    page.spacing = 0
    page.rtl = True

    preferences = ft.SharedPreferences()
    file_picker = ft.FilePicker()
    clipboard = ft.Clipboard()
    balance, transactions = await load_wallet(preferences)
    state = {"logged_in": False}
    screen_host = ft.Container(expand=True, max_width=560)
    navigation_host = ft.Container(max_width=560)

    async def validate_login(username, password):
        if username.strip() == "admin" and password == "admin123":
            state["logged_in"] = True
            show_screen("home")
            log.info("Demo administrator signed in")
            return True
        return False

    async def send_demo(recipient, raw_amount, note):
        nonlocal balance, transactions
        try:
            amount = float(raw_amount.strip().replace(",", ""))
        except (AttributeError, ValueError):
            return "أدخل مبلغاً صحيحاً."
        if not recipient.strip():
            return "أدخل عنوان المستلم أو اسمه."
        if amount <= 0:
            return "يجب أن يكون المبلغ أكبر من صفر."
        if amount > balance:
            return "الرصيد التجريبي غير كافٍ."

        balance -= amount
        transaction = {
            "id": str(603510700 + len(transactions)),
            "title": recipient.strip(),
            "subtitle": "اليوم · عملية تجريبية",
            "amount": amount,
            "direction": "out",
            "currency": "ل.س",
            "sender": "admin",
            "sender_account": "************2846",
            "recipient": recipient.strip(),
            "recipient_account": "************3734",
            "note": note.strip() or "—",
        }
        transactions.insert(0, transaction)
        await save_wallet(preferences, balance, transactions)
        log.info("Stored demo transfer %s", transaction["id"])
        show_screen("receipt", transaction)
        return None

    async def pick_transfer_image():
        selected = await file_picker.pick_files(
            allowed_extensions=["png", "jpg", "jpeg"],
            allow_multiple=False,
        )
        return selected[0].name if selected else None

    async def copy_address(value):
        await clipboard.set(value)

    def open_transaction(item):
        show_screen("receipt", item)

    def build_navigation(active):
        def nav_item(key, label, icon):
            selected = active == key or (active == "receipt" and key == "activity")
            return ft.Container(
                expand=True,
                content=ft.TextButton(
                    content=ft.Column(
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=3,
                        controls=[
                            ft.Icon(icon, size=21, color=BLUE if selected else MUTED),
                            ft.Text(label, size=10, color=BLUE if selected else MUTED, max_lines=1),
                        ],
                    ),
                    on_click=lambda e, target=key: show_screen(target),
                ),
            )

        return ft.Container(
            padding=ft.Padding.symmetric(horizontal=9, vertical=7),
            bgcolor="#171A29",
            border=ft.Border(top=ft.BorderSide(width=1, color="#30364B")),
            content=ft.Row(
                spacing=2,
                controls=[
                    nav_item("home", "الرئيسية", ft.Icons.HOME),
                    nav_item("activity", "التحويلات", ft.Icons.SWAP_HORIZ),
                    ft.Container(
                        width=56,
                        height=56,
                        border_radius=28,
                        bgcolor=BLUE,
                        alignment=ft.Alignment.CENTER,
                        ink=True,
                        on_click=lambda e: show_screen("receive"),
                        content=ft.Icon(ft.Icons.QR_CODE_SCANNER, size=25, color=WHITE),
                    ),
                    nav_item("services", "الخدمات", ft.Icons.CREDIT_CARD),
                    nav_item("account", "حسابي", ft.Icons.PERSON_OUTLINE),
                ],
            ),
        )

    def show_screen(name, item=None):
        if not state["logged_in"] and name != "login":
            name = "login"

        if name == "login":
            screen_host.content = build_login(validate_login)
            navigation_host.content = None
        elif name == "home":
            screen_host.content = build_dashboard(
                balance,
                transactions,
                lambda e: show_screen("send"),
                lambda e: show_screen("receive"),
                lambda e: show_screen("activity"),
                lambda e: show_screen("services"),
                lambda e: show_screen("account"),
                lambda e: show_screen("notifications"),
                open_transaction,
            )
            navigation_host.content = build_navigation(name)
        elif name == "send":
            screen_host.content = build_send(
                balance,
                send_demo,
                pick_transfer_image,
                lambda e: show_screen("home"),
            )
            navigation_host.content = build_navigation(name)
        elif name == "receive":
            screen_host.content = build_receive(copy_address, lambda e: show_screen("home"))
            navigation_host.content = build_navigation(name)
        elif name == "activity":
            screen_host.content = build_activity(transactions, open_transaction, lambda e: show_screen("home"))
            navigation_host.content = build_navigation(name)
        elif name == "receipt":
            screen_host.content = build_receipt(item or (transactions[0] if transactions else {}), lambda e: show_screen("activity"))
            navigation_host.content = build_navigation(name)
        elif name == "notifications":
            screen_host.content = build_notifications(transactions, open_transaction, lambda e: show_screen("home"))
            navigation_host.content = build_navigation(name)
        elif name == "services":
            screen_host.content = build_services(lambda e: show_screen("home"), lambda e: show_screen("send"))
            navigation_host.content = build_navigation(name)
        else:
            screen_host.content = build_account(lambda e: show_screen("home"), logout)
            navigation_host.content = build_navigation(name)
        page.update()

    def logout():
        state["logged_in"] = False
        show_screen("login")

    page.add(
        ft.SafeArea(
            expand=True,
            content=ft.Column(
                expand=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=0,
                controls=[screen_host, navigation_host],
            ),
        )
    )
    show_screen("login")


ft.run(main)
