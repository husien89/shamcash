import flet as ft

from theme import CARD, LINE, MUTED, RED, GREEN, TEXT, SURFACE


def build_transaction_card(item, on_click=None, compact=False):
    outgoing = item.get("direction", "out") == "out"
    amount_color = RED if outgoing else GREEN
    prefix = "−" if outgoing else "+"
    amount = float(item.get("amount", 0))
    currency = item.get("currency", "ل.س")
    amount_text = f"{prefix} {amount:,.0f} {currency}"

    details = [
        ft.Text(item.get("title", item.get("recipient", "عملية محفظة")), size=15, weight=ft.FontWeight.W_600, color=TEXT),
        ft.Text(amount_text, size=15, weight=ft.FontWeight.BOLD, color=amount_color),
    ]
    if not compact:
        details.append(ft.Text(item.get("note", "تحويل عبر ShamCash"), size=12, color=MUTED, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS))

    right = [
        ft.Text(f"#{item.get('id', '603510700')}", size=12, color=MUTED),
        ft.Text(item.get("subtitle", "اليوم"), size=11, color=MUTED, text_align=ft.TextAlign.RIGHT),
    ]

    content = ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
        controls=[
            ft.Column(expand=True, spacing=7, controls=details),
            ft.Column(horizontal_alignment=ft.CrossAxisAlignment.END, spacing=7, controls=right),
        ],
    )

    return ft.Container(
        padding=ft.Padding.all(15 if compact else 17),
        border=ft.Border.all(1, LINE),
        border_radius=18,
        bgcolor=CARD if not compact else SURFACE,
        ink=on_click is not None,
        on_click=(lambda e: on_click(item)) if on_click else None,
        content=content,
    )
